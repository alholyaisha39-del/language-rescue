/* ألصقي إعدادات مشروع Firebase للمدرسة هنا.
   لا تضعي بريد المعلمة وكلمة مرورها معًا هنا، كلمة المرور تدخلها المعلمة فقط من نموذج الدخول. */
window.LANGUAGE_RESCUE_CLOUD = {
  firebaseConfig: null,
  teacherEmail: ''
};
